package com.Assignment1.Customer;


class Customer{
	private String name;
	private int age;
	private String address;
	
	void acceptRecord(String name,int age,String address){
	this.name=name;
	this.age=age;
	this.address=address;
	}
	
}


public class Program {
	public static void main(String[] args) {
		
		
		String name=args[0];
		int age=Integer.parseInt(args[1]);
		String address=args[2];
		
		Customer c=new Customer();
		c.acceptRecord(name, age, address);
		

		}
}
