package com.Assignment1.Date;


class Date{
	private int day;
	private int month;
	private int year;
	
	
	//Parameterless Constructor
	public Date(){
		this.day=1;
		this.month=1;
		this.year=2016;
	}
	
	//Parameterized Constructor
	public Date(int day, int month, int year) {
		
		this.day = day;
		this.month = month;
		this.year = year;
	}
	
	
	//To Display Values
	public void print(){
	System.out.println("Date  " + this.day + "/"  + this.month +  "/" +this.year);	
	}
	
}


public class Program {
	
public static void main(String[] args) {
	
	//Object creation using parameterless constructor
	Date d1=new Date();
	d1.print();
	
	//Object creation using parameterized constructor
	Date d2=new Date(12,02,2017);
	d2.print();
}
}

