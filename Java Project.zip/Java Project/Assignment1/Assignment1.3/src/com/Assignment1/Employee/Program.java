package com.Assignment1.Employee;

class Employee{
	String name;
	int age;
	int salary;
	
	//Parameterless Constructor
	public Employee(){
		this.name="";
		this.age=0;
		this.salary=0;
	}
	
	//Parameterized Constructor
	public Employee(String name, int age, int salary) {
		super();
		this.name = name;
		this.age = age;
		this.salary = salary;
	}
	
	//Mutators: To set the fields of Employees
public void setEmployee(String name, int age, int salary){
	this.name=name;
	this.age=age;
	this.salary=salary;
}


//Accessors:To get the values of Employees	
public Employee getEmployee(){
	Employee e=new Employee();
	e.name=this.name;
	e.age=this.age;
	e.salary=this.salary;
	return e;
}

//To print the value of Employee
public void displayEmployee(){
	System.out.println("Employee Details :"+ this.name + "  " + this.age + "  " + this.salary);
	
}
}

public class Program {

	public static void main(String[] args) {
		
		//Object creation using Parameterless Constructor
		Employee emp1=new Employee();
		emp1.setEmployee("Shailja",23,24000);
		
		//For Displaying values
		emp1.displayEmployee();
		
		
		
		//Object creation using Parameterized Constructor
		Employee emp2=new Employee("Shaily",22,24568);
		
		
		//For Displaying values
		emp2.displayEmployee();
	}
}

