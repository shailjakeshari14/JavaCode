package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


class Utility{
	
	// URL,USERNAME,PASSWORD Declaration
	static final String URL="jdbc:mysql://localhost/mydb";
	static final String USERNAME="root";
	static final String PASSWORD="root";
	
	//Initializing Prepared Statement
	PreparedStatement stmnt=null;
	
	//Creating connection
	public Connection createConnection() throws ClassNotFoundException, SQLException{
		
//Loading Driver Name
Class.forName("com.mysql.jdbc.Driver");

//Passing URL,USERNAME,PASSWORD
Connection con=DriverManager.getConnection(URL,USERNAME,PASSWORD);
	return con;	
	
	
}

//Insertion
public void insert(Connection con) throws SQLException{
	
	stmnt=con.prepareStatement("Insert into Employee values(?,?,?)");
	stmnt.setInt(1, 1005);
	stmnt.setString(2, "Raju");
	stmnt.setDouble(3, 72345.89);
	int i=stmnt.executeUpdate();
	System.out.println("Reords Inserted :" +i);
	
}

//For Updation
public void update(Connection con) throws SQLException{

stmnt=con.prepareStatement("Update Employee set name=? where empid=?");

stmnt.setString(1,"jolly");
stmnt.setInt(2,1002);
int i=stmnt.executeUpdate();

System.out.println("Records Updated  :" +i);

}

//Closing Various Resources
public void closeResource(Connection con) throws SQLException{
	
	if(con!=null)
		con.close();
	if(stmnt!=null)
		stmnt.close();
		
}

}//End Of Utility Class


public class Program {

public static void main(String[] args) {
	
	
	try {
		Utility util=new Utility();
		
		Connection con=util.createConnection();
		util.insert(con);
		util.update(con);
		util.closeResource(con);
		
		
	} catch (ClassNotFoundException | SQLException e) {
		
		e.printStackTrace();
	}
	
}//End Of Main Method

}//End Of Program Class
