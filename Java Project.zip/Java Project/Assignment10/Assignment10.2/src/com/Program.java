package com;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Program {
	
	// URL,USERNAME,PASSWORD Declaration
	static final String URL="jdbc:mysql://localhost/mydb";
	static final String USERNAME="root";
	static final String PASSWORD="root";
	
	public static void main(String[] args) {
		
	Connection con=null;
	CallableStatement stmnt=null;
	
	try {
		//Loading Driver Name
		Class.forName("com.mysql.jdbc.Driver");
	
		//Passing URL,USERNAME,PASSWORD
		 con=DriverManager.getConnection(URL,USERNAME,PASSWORD);
		
		
		String proc="{call UpdateSalary()}";
		
		//Calling Prepared Statement
		 stmnt=con.prepareCall(proc);
		
	int success =	stmnt.executeUpdate();
	
	if(success!=0){
		System.out.println("Congo !!! Your Salary is incremented by 10%");
	}
	
		
	} catch (ClassNotFoundException e ) {
		e.printStackTrace();
		
	} 
	
	catch (SQLException e) {
	e.printStackTrace();
		
	}
	finally{
		try {
			
		//Closing the Resources	
			
		if(con!=null)
				con.close();
		
		if(stmnt!=null)
                stmnt.close();
                
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
	}//End Of Finally Block
	
	}//End of main method
}//End Of Program Class
