package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class Program {
	
	// URL,USERNAME,PASSWORD Declaration
	static final String URL="jdbc:mysql://localhost/mydb";
	static final String USERNAME="root";
	static final String PASSWORD="root";
	
	static Connection con=null;
	static Statement stmnt=null;
	static ResultSet res=null;
	
	public static void main(String[] args) {
		
		try {
			
			//Loading Driver Name
			Class.forName("com.mysql.jdbc.Driver");
			
			//Passing URL,USERNAME,PASSWORD
			 con=DriverManager.getConnection(URL,USERNAME,PASSWORD);
			stmnt=con.createStatement();
			String query="Select * from Employee";
			ResultSet res=stmnt.executeQuery(query);
			
			ResultSetMetaData meta=res.getMetaData();
			
			 //number of columns in database
			int count = meta.getColumnCount();
			
			//Creating Array to store new column
			String columnName[] = new String[count];

			
			//Storing Column name in array
			for (int i = 1; i <= count; i++)
			{
			   columnName[i-1] = meta.getColumnLabel(i); 
			}
				
			
			//Displaying Column Name
			for (String string : columnName) {
				System.out.print(string  + "   ");
			}
			System.out.println();
			
			//Displaying Column Data
			while(res.next()){
				System.out.print(res.getInt(1) + "   ");
				System.out.print(res.getString(2) + "   ");
				System.out.print(res.getDouble(3) + "   ");
				System.out.println();
				
			}
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			
				try {
					if(con!=null)
					con.close();
					if(stmnt!=null)
						stmnt.close();
					if(res!=null)
						res.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
			
		}
	}
}
