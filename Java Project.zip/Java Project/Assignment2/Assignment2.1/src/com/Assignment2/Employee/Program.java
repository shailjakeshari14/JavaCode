package com.Assignment2.Employee;

class Employee{
	String name;
	int age;
	int salary;
	
	// static variable to count the number of objects created
	static int count;
	
	//parameterless constructor
	public Employee(){
		this.name="";
		this.age=0;
		this.salary=0;
		count++;
	}
	
	//parameterized constructor
	public Employee(String name, int age, int salary) {
		
		this.name = name;
		this.age = age;
		this.salary = salary;
		count++;
	}
	
	
}

public class Program {
public static void main(String[] args) {
	//Creation Of Array Of Employees 
	Employee [] emp={new Employee(),new Employee("Shailja",23,50000),new Employee()};
	
	//Displaying Number of Objects created
	System.out.println("Number Of objects created :" +Employee.count);
}
}
