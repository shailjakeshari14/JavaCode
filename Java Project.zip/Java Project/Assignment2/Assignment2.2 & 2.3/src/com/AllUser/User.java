package com.AllUser;
import com.Assignment2.Root.*;




public class User {
 
	public static void main(String[] args) {
		
		//Making object of calc to calculate Square Root
		Calc c=new Calc();
		c.findRoot(32);
	}
}
