package com.Assignment2.Root;


public class Calc{
	
	// Find Root Method
	public void findRoot(int num){
		
		
		//Calculating Square Root
		double root=Math.sqrt(num);
		System.out.println(root);
	}
}
