package com.Assignment3.Money;

public class Money {
public int basicFee;

//Basic fee for Patient Rs.1200,50
public Money(){
	this.basicFee=120050;
}
}
