package com.Assignment3.Patient;

import com.Assignment3.Money.*;

//SuperType
class Person{
	String name;
	int age;
	
	
	
	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	
}

// Single Inheritance
class Patient extends Person{
	int patientNo;
	String hospitalName;
	String joiningYear;
	String address;
	int medicalFees;
	
	
	//Parameterized Constructor
	public Patient(String name, int age, int patientNo,String hospitalName, String joiningYear, String address, int medicalFees) {
		super(name, age);
		this.patientNo = patientNo;
		this.hospitalName=hospitalName;
		this.joiningYear = joiningYear;
		this.address = address;
		this.medicalFees = medicalFees;
	}

	//Setting various details of patient
	public void setPatientDetails(String hospitalName, String joiningYear, String address){
		this.hospitalName=hospitalName;
		this.joiningYear = joiningYear;
		this.address = address;
	}
	
	//Getting various details of patient
	public void getPatientDetails(){
	System.out.println("Patient Details are :  Hospital Name = " + this.hospitalName + "  Joining Year = "  + this.joiningYear + "  Address = " + this.address);	
	}
	
	//Calculate TotalFees including basic fee and medical fee
	public void calculateMedicalFee(Money m){
	this.medicalFees=m.basicFee+this.medicalFees;
	System.out.println("Total Medical Fees Of Patient :" +this.medicalFees);
	}
}


public class Program {

	public static void main(String[] args) {
		
		//Object Creation
		Patient p=new Patient("Shailja",23,1234,"AIMS","2016","Pune",1000);
		
		//Setting Patient details
		p.setPatientDetails("PGI", "2016", "Lucknow");
		
		//Getting Patient details
		p.getPatientDetails();
		
		Money m=new Money();
		
		//Calculating Medical Fees
		p.calculateMedicalFee(m);
	}
}
