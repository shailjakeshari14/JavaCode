package com.Bank;

//Super type
class BankAccount{
	String name;
    int rateOfIntrest;
    
    public int getRateOfIntrest(){
    return 0;	
    }
}

//Sub type
class SavingBankAccount extends BankAccount{
	
	public int getRateOfIntrest(){
		return 5;
	}
}

//Sub type
class CurrentBankAccount extends BankAccount{
	
	
	public int getRateOfIntrest(){
		return 8;
	}
}
public class Program {

	public static void main(String[] args) {
		
	//Super Type Object Creation	
	BankAccount b=new BankAccount();
	System.out.println("Bank Account Rate Of Intrest  :" +b.getRateOfIntrest());
	
	//Sub Type Object Creation
	SavingBankAccount s=new SavingBankAccount();
	System.out.println("Saving Bank Account Rate Of Intrest  :" +s.getRateOfIntrest());
	
	//Sub Type Object Creation
	CurrentBankAccount c=new CurrentBankAccount();
	System.out.println("Current Bank Account Rate Of Intrest  :" +c.getRateOfIntrest());
	}
}
