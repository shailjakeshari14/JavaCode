package com.Assignment4.Animal;


//Supertype
class Animal{
	String communcationStyles;
	boolean isCarnivore;
	
	
	
	
	public Animal(String communcationStyles, boolean isCarnivore) {
		super();
		this.communcationStyles = communcationStyles;
		this.isCarnivore = isCarnivore;
	}
	
	

	public void respirate(){
		System.out.println("Different animals has different respiration styles");
	}
	
	
	public void talk(){
		System.out.println("Different animals have different communication styles");
	}
}


//Subtype
class Cat extends Animal{

	
	
	public Cat(String communcationStyles, boolean isCarnivore) {
		super(communcationStyles, isCarnivore);
	}

	//Overridden from Super class
	public void talk(){
		System.out.println("Cat communication style are MEWING,GROWLING AND GRUNTING");
	}
	
}


//Subtype
class Dog extends Animal{

	
	
	
	public Dog(String communcationStyles, boolean isCarnivore) {
		super(communcationStyles, isCarnivore);
	}

	//Overridden from Super class
	public void talk(){
		System.out.println("Dog communication style is Barkening");
	}
}


//Subtype
class Lion extends Animal{

	
	
	public Lion(String communcationStyles, boolean isCarnivore) {
		super(communcationStyles, isCarnivore);
	}

	//Overridden from Super class
	public void talk(){
		System.out.println("Lion communication styles are GROWLING AND GRUNTING");
	}
}

public class Program {

	public static void main(String[] args) {
		
		//Array of Animals
	Animal [] animals={new Cat("Meowing",true),new Dog("Barkening",true),new Lion("Growling",true)};
		
		// Achieving Dynamic Polymorphism
		animals[0].talk();
		animals[1].talk();
		animals[2].talk();
	}
}
