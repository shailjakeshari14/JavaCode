package com.Assignment4.Vechile;


//Supertype
class Vehicle{
	String companyName;
	int price;

	public Vehicle(String companyName, int price) {
		super();
		this.companyName = companyName;
		this.price = price;
	}


	public void move(){
		System.out.println("Different vehicles have different moving speeds !!!");
	}
}

//Subtype
class Car extends Vehicle{

	public Car(String companyName, int price) {
		super(companyName, price);
	}

//Overriden method
	public void move(){
		System.out.println("CAR speed ranges from 30 to 200 km/hr");
	}
}

//Subtype
class Motorbike extends Vehicle{

	public Motorbike(String companyName, int price) {
		super(companyName, price);
	}
	
	//Overriden method
	public void move(){
		System.out.println("MOTORBIKE speed ranges from 60 to 400 km/hr");
	}
	
}

//Subtype
class Truck extends Vehicle{

	public Truck(String companyName, int price) {
		super(companyName, price);
	}
	
	//Overriden method
	public void move(){
		System.out.println("TRUCK speed ranges from 60 to 150 km/hr");
	}
	
}

public class Program {

	public static void main(String[] args) {
		
		//Array of Vehicle Refrences
		Vehicle [] vehicles={new Car("Hyundai",500000),new Motorbike("Bajaj",40000),new Truck("Tata",900000)};
		
		//Achieving Dynamic Polymorphism
		vehicles[0].move();
		vehicles[1].move();
		vehicles[2].move();
	}
	
}
