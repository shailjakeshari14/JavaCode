package com.Assignment.Printable;


public interface Printable {

public void print();
}
