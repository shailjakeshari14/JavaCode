package com.Assignment.Printable;

class Shape implements Printable{
	
	String shapeType;
	int area;
	
	

	public Shape(String shapeType, int area) {
		super();
		this.shapeType = shapeType;
		this.area = area;
	}


	@Override
	public void print() {
		System.out.println("Shape information are :  Shape Type  = " + this.shapeType + " Shape Area  = " +this.area);
	}
	
}

class Animals implements Printable{
	String name;
	String order;
	

	public Animals(String name, String order) {
		super();
		this.name = name;
		this.order = order;
	}

	@Override
	public void print() {
		System.out.println("Shape information are :  Shape Type  = " + this.name + " Shape Area  = " +this.order);
	}
	
}

class Utility{
	
	//For prinitng all the objects of array
	public void printAll(Printable [] arr){
	for (Printable printable : arr) {
		printable.print();
	}
	
	}
}

public class Program {

	public static void main(String[] args) {
	
		//Created array of printable refrences
		Printable [] arr={new Shape("Rectangle",280),new Animals("Lion","Carnivores"),new Shape("Triangle",150),new Animals("Dog","Carnivores")};
		Utility util=new Utility();
		
		//Passing the array of printables to the method of Utility class
		util.printAll(arr);
	}
}
