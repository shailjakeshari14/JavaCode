package com.Assignment5.Employee;

class Employee{
	String name;
	int age;
	int salary;
	
	
	public Employee(String name, int age, int salary) {
		super();
		this.name = name;
		this.age = age;
		this.salary = salary;
	}
	
	//Overridden equals method
	@Override
	public boolean equals(Object obj) {
		Employee emp=(Employee)obj;
		
		if(this.name==emp.name)
		return true;
		else if(this.age==emp.age)
			return true;
		else if(this.salary==emp.salary)
			return true;
		else
			return false;
	}
	
	//Overridden toString method
	@Override
	public String toString() {
		return String.format("Employee Details :  Name = " + this.name + " Age = " + this.age + " Salary = " + this.salary);
	}
}



public class Program {
public static void main(String[] args) {
	
	Employee emp1=new Employee("Jack",25,34567);
	
	Employee emp2=new Employee("Jack",25,34567);
	
	//Object Comparison
	if(emp1.equals(emp2))
		System.out.println("Both the Employee data is equal");
	else
		System.out.println("Both the Employee data is unequal");
		
	
	// Displaying Employee Details 
	System.out.println(emp1);
}
}
