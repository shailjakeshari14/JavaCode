package com.Assignments5.Account;



class Account{
	String type;
	int accountNumber;
	
	
	public Account(String type, int accountNumber) {
		super();
		this.type = type;
		this.accountNumber = accountNumber;
	}
	
	//Overridden equals method
		@Override
		public boolean equals(Object obj) {
			Account account=(Account)obj;
			
			if(this.type==account.type)
			return true;
			else if(this.accountNumber==account.accountNumber)
				return true;
			
			else
				return false;
		}
		
		//Overridden toString method
		@Override
		public String toString() {
			return String.format("Account Details :  Type = " + this.type + " Account Number = " + this.accountNumber );
		}
	
}



public class Program {
	
	public static void main(String[] args) {
		
	
Account acc1=new Account("Current",123456);
Account acc2=new Account("Current",4567890);

//Object Comparison
	if(acc1.equals(acc2))
		System.out.println("Both the Account data is equal");
	else
		System.out.println("Both the Account data is unequal");
		
	
	// Displaying Account Details 
	System.out.println(acc1);
}
}
