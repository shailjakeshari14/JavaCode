package com.Assignment.gcc;

public class GarbageCollection {

//defining finalize Method
	public void finalize(){
		System.out.println("Object is ready for garbage collection");
	}
	
	
	public static void main(String[] args) {
		GarbageCollection gc1=new GarbageCollection();
		GarbageCollection gc2=new GarbageCollection();
		gc1=null;
		gc2=null;
		
		
		System.gc();// Invoking gc for cleaning
	}
}
