package com.Assignment.Sort;

public class Program {

	public static void main(String[] args) {
		
	int arr[]=new int[10];
	
	int j,temp,i;
	
	for(i=0;i<args.length;i++){
		arr[i]=Integer.valueOf(args[i]);// Taking argument from Command Line
		
	}
	
	//Unsorted Elements are:
	System.out.println("Elements in the unsorted array are :");
	for(i=0;i<args.length;i++){
		System.out.println(arr[i]);    //Printing Elements
	}
	
	
	//Sorting Of Elements :
	for(i=0;i<args.length;i++){
		
		for(j=0;j<args.length-i-1;j++){
			if(arr[j]>arr[j+1]){
				//Sorting Logic
				temp=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=temp;
			}
		}
	}
	
	//Sorted Elements are:
	System.out.println("Elements in the Sorted array are :");
	for(i=0;i<args.length;i++){
		System.out.println(arr[i]);
	}
	}
}
