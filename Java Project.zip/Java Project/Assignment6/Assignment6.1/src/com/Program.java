package com;

// Created Exception Class to handle Sewing Machine failure
class MachineNotWorkingException extends Exception{
	String message;

	public MachineNotWorkingException() {
    System.out.println("Warning !!!");
}
	
	
}

class SewingMachine{
	String functionality;
	String containsThread;
	
	public SewingMachine(String functionality, String containsThread) {
		
		this.functionality = functionality;
		this.containsThread = containsThread;
	}

	public void working() throws MachineNotWorkingException //Declaration Of Exception
	{
		if(this.functionality=="execute" && this.containsThread=="no" )
			throw new MachineNotWorkingException();
			
	}
		
}

public class Program {

	public static void main(String[] args) {
		
		SewingMachine sm=new SewingMachine("execute","no");
		
		try {
			sm.working();
			
			//Handling the exceptions
		} catch (MachineNotWorkingException e) {
			System.out.println("Dear User !!!! Kindally Check your Spool Holder.It is empty");
		}
		
	}
	
}
