package com;

import java.util.TreeSet;


// Implemented Comparable Interface for Sorting 
class Employee implements Comparable<Employee>{
	
	int empId;
	String name;
	int salary;
	
	
	
	public Employee(int empId, String name, int salary) {
		
		this.empId = empId;
		this.name = name;
		this.salary = salary;
	}


	

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", salary=" + salary + "]";
	}



//Overrides the compareTo and sort it on the basis of employee id
	@Override
	public int compareTo(Employee o) {
		if(this.empId==o.empId)
			return 0;
		else if(this.empId > o.empId)
			return 1;
		else
			return -1;
	}
	
	
}

public class SortedSetImpl {
	
	//Adding Employee Objects on the TreeSet
	public static void createSet(TreeSet<Employee> set){
		
		set.add(new Employee(1005,"Shailja",34567));
		set.add(new Employee(1003,"Sneha",34507));
		set.add(new Employee(1001,"Sheetal",34587));
		set.add(new Employee(1004,"Kalyani",34597));
		set.add(new Employee(1002,"Utkarsha",34557));
	}
	
	
	//will Display the Objects inside the treeSet
	public static void displaySet(TreeSet<Employee> set){
		for (Employee employee : set) {
			System.out.println(employee);
		}
	}

public static void main(String[] args) {
	
	// TreeSet References created to store the Employee Objects
	TreeSet<Employee> employeeSet=new TreeSet<Employee>();
	
	createSet(employeeSet);
	
	displaySet(employeeSet);
}
}
