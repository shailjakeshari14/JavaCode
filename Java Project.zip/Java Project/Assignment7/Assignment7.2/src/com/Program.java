package com;

import java.util.ArrayList;

import java.util.List;


 class Patient extends Person {
	
	int patientId;
	String disease;
	
	public Patient(String name, String address, int patientId, String disease) {
		super(name, address);
		this.patientId = patientId;
		this.disease = disease;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

 }
 

public class Program{
	
	public static void main(String[] args) {
		
		List<Person> patientList=new ArrayList<Person>();
		
		Utility.createRecord(patientList);
		
int choice=2;

	switch(choice){
	
	
	case 0:
		break;
	
		
	case 1:
		Utility.updateAddress(patientList,"Jack");
		break;
		
		
	case 2:
		Utility.removePatient(patientList,"Jack");
		break;
		
		
	case 3:
		Utility.getSize(patientList);
		break;
	}
}

}


