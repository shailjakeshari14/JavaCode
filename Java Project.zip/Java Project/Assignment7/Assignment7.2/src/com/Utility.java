package com;

import java.util.List;

public class Utility {
	 public static void createRecord(List<Person> patientList){
			
			
			Patient p1=new Patient("Jack","London",1001,"Jaundice");
			Patient p2=new Patient("Alice","Calfornia",1002,"Typhoid");
			Patient p3=new Patient("Robin","Texas",1003,"High Fever");
			Patient p4=new Patient("Snak","London",1004,"Cholera");
			Patient p5=new Patient("Lucky","Los Vegas",1005,"Jaundice");
			
			patientList.add(p1);
			patientList.add(p2);
			patientList.add(p3);
			patientList.add(p4);
			patientList.add(p5);
			
			System.out.println("Record's created");
		
		}
		
		public static void getSize(List<Person> patientList){
			int sizeOfList=patientList.size();
			System.out.println(sizeOfList);
			
		}
		
		public static void updateAddress(List<Person> patientList,String name){
			
			for (Person patient : patientList) {
			if(patient.name==name)
				System.out.println(name + "Previous Address is  " +patient.getAddress());
				patient.setAddress("Pune");
			}
			
		}
		
		public static void removePatient(List<Person> patientList,String name){
			
			Patient p=null;
			for (Person patient : patientList) {
				if(patient.name==name)
				 p=(Patient)patient;
				
			}
			
			System.out.println(p.name +"Information is Removed");
			patientList.remove(p);
			System.out.println("Patient Removed");
}
}