package com;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

class Book{
	
	int bookId;
	String name;
	String author;
	String publisher;
	
	
	public Book(int bookId, String name, String author, String publisher) {
		super();
		this.bookId = bookId;
		this.name = name;
		this.author = author;
		this.publisher = publisher;
	}


	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", name=" + name + ", author=" + author + ", publisher=" + publisher + "]";
	}

	
//Overrides hash code method
	@Override
	public int hashCode() {
		final int prime = 31;
		int result;
		result=prime+this.bookId;
		return result;
	}


	//Overrides equals method
	@Override
	public boolean equals(Object obj) {
	
		Book bk=(Book) obj;
		if(this.bookId==bk.bookId)
		return true;
		else if(this.bookId>bk.bookId)
			return false;
		else
			return false;
	}
	
	
}//End Of Book Class


public class Program {
	
	
	//Adding Books in the HashMap
	public static void addBooks(HashMap<Book,Integer> books){
		
		//Creating book objects
		Book b1=new Book(1001,"Java","James Gousling","Penguin");
		Book b2=new Book(1002,"Let Us C","Dennis Ritchie","Penguin");
		Book b3=new Book(1003,"Operating Sysytem","Silver S","Tata MgGra Hills");
		Book b4=new Book(1004," Advance Java","James Gousling","Penguin");
		Book b5=new Book(1005,"ASP.net","Jack","Eagle");
		
		//Adding book Object as a Key and Number of pages as value
		books.put(b1, 1234);
		books.put(b2, 1500);
		books.put(b3, 1700);
		books.put(b4, 1800);
		books.put(b5, 1900);
		
	}
	
	
	
	public static void print(HashMap<Book,Integer> hm){
		
		//Using Iterator to Display the content of Map
		 Iterator it = hm.entrySet().iterator();
		    while (it.hasNext()) {
		        Map.Entry pair = (Map.Entry)it.next();
		        System.out.println(pair.getKey() + " = " + pair.getValue());
			
		    }
	}

	public static void main(String[] args) {
		
		//Creation Of Hash map with the no of Pages
		HashMap<Book,Integer> books=new HashMap<Book,Integer>();
	
		addBooks(books);
		print(books);
	
	}//End Of Main Method
	
}//End of Program Class
