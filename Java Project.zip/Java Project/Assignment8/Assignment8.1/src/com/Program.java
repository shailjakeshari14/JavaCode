package com;



import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;

public class Program {
	
	public static void main(String[] args) {
		
		//Scanning Input From the user
		Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        BufferedWriter bwr;
		try {
			
			//Creating File Writer Object
			FileWriter fw = new FileWriter("file.dat");
			
			bwr = new BufferedWriter(fw);
			
			bwr.write(s);
			
	        bwr.flush();
	        
	        //Closing the Buffer Writer
	        bwr.close();
	        
		} catch (IOException e) {
			
			e.printStackTrace();
		}
        
		// Source file
		File sourceFile = new File("file.dat");

		//destination file
		File destFile = new File("file2.dat");
		
		InputStream input = null;
		
		OutputStream output = null;
		
		try {

			//Creating File Input Stream
			input = new FileInputStream(sourceFile);

			// Creating  File Output Stream 
			output = new FileOutputStream(destFile);

			byte[] bufr = new byte[1024];
			int bytesRead;

			while ((bytesRead = input.read(bufr)) > 0) {
				output.write(bufr, 0, bytesRead);
			}
			
			

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("Successfully Completed !!!!!");
	}

}

