package com;

import java.util.Date;
import java.io.FileInputStream;

import java.io.FileOutputStream;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.DateFormat;

import java.text.SimpleDateFormat;

class Account implements Serializable{
	
	String name;
	Date doc;
	transient int acuntNo;
	
	
	public Account(String name, Date doc, int acuntNo) {
		super();
		this.name = name;
		this.doc = doc;
		this.acuntNo = acuntNo;
	}
}//End Of Account Class

public class Program {
	public static void main(String[] args) {
		
		
		//Creating Date Format
		DateFormat dt= new SimpleDateFormat("dd-mm-yyyy");
		
		Date date;
	
			
		
		
		//Serialization
		try {
			date = (Date) dt.parse("01-09-2016");
			
			Account account = new Account("Shailja", date, 678);
		
			FileOutputStream fs= new FileOutputStream("acnt.data");
			
			ObjectOutputStream oots= new ObjectOutputStream(fs);
			
			//Writing in File
			oots.writeObject(account);
			
			oots.flush();
			
		
		} catch (Exception e) {
System.out.println("Unable to Serialize");
		}
		
		
		
		//Deserialization
		
		try {
			ObjectInputStream on= new ObjectInputStream(new FileInputStream("acnt.data"));
			
			//Getting Info From The File
			Account acc= (Account) on.readObject();
			
			System.out.println(" Name  =" +acc.name+  " " + "  Date=  " + acc.doc);
			on.close();
	
		} catch (Exception e) {
			System.out.println("Unable to Deserialize");
		}
	}

}


