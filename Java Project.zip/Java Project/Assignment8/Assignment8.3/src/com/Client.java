package com;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		try {
			Socket sock= new Socket("172.27.74.219",2000);	//Creating socket Object
			
			// sending from client
			BufferedReader bfr= new BufferedReader(new InputStreamReader(sock.getInputStream()));
			
			// receiving from server
			PrintWriter pwr= new PrintWriter(sock.getOutputStream());	
			
			BufferedReader bin= new BufferedReader(new InputStreamReader(System.in));
			
			String s;
			
			while(true)
			{
				System.out.println("Client Side ");
				s= bin.readLine();		//reading from keyboard
				pwr.println(s);
				s= bfr.readLine();
				System.out.println("Server side"+s+"\n");
				if(s.equalsIgnoreCase("I am Going"))
					break;
				
			}
			//closing the objects
			sock.close();
			bfr.close();
			pwr.close();
			bin.close();
			
		
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}//End Of Main Method

}//End Of Program
