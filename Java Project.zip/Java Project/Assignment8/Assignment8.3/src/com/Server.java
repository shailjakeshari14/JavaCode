package com;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static void main(String[] args)throws Exception {
		
		
		//Creating Server Side Object
		ServerSocket ss= new ServerSocket(2000);		
		Socket sk= ss.accept();
		
		//reading from keyboard
		BufferedReader bfr= new BufferedReader(new InputStreamReader(sk.getInputStream()));	// sending to client
		
		PrintWriter pw= new PrintWriter(sk.getOutputStream());		// receiving from server
		
		BufferedReader bin= new BufferedReader(new InputStreamReader(System.in));
		
		String s;
		while(true)
		{
			s= bfr.readLine();
			if (s.equalsIgnoreCase("How R U ??"))
  			{
				pw.println("BYE");
    				break;
  			  }
			System. out.print("Client Side : "+s+"\n");
			System.out.print("Server Side : ");
			s=bin.readLine();
			pw.println(s);
		}
		
		//closing the objects
		ss.close();
		sk.close();
		bfr.close();
		pw.close();
		bin.close();
}
}