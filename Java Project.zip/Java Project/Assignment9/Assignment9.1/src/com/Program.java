package com;



public class Program {
	
	public static Object way1 = new Object();
	   public static Object way2 = new Object();
	   
	   public static void main(String args[]) {
	   
		   //Initalising Different Threads
	      Thread1 T1 = new Thread1();
	      Thread2 T2 = new Thread2();
	      Thread3 T3 = new Thread3();
	      T1.start();
	      T2.start();
	      T3.start();
	      
	   }
	   public void displayLight()
	    {
	        System.out.println("The Light is "+ Thread.currentThread().getName());
	    }
	   
	   private static class Thread1 extends Thread {
		   
	      public void run() {
	    	  
	         synchronized (way1) {
	            System.out.println("RED : Way 1 Waiting");
	            
	            		try {
	            			Thread.sleep(1000);
	            			
	            			}
	            		
	            catch (InterruptedException e) {
	            	
	            	e.printStackTrace();
	            }
	            synchronized (way2) {
	            	
	               System.out.println("Green: Way 2 is running ...");
	            }
	         }
	      }
	   }//End Of Thread1 Class
	   
	   
	   private static class Thread2 extends Thread {
	      public void run() {
	    	  
	         synchronized (way1) {
	        	 
	            System.out.println("Orange: Way 1 is ready to go");
	            
	            try {
	            	
	            	Thread.sleep(1000);
	            }
	            catch (InterruptedException e) {
	            	e.printStackTrace();
	            }
	            synchronized (way2) {
	            	
	               System.out.println("Orange: Way2 is ready to stop");
	            }
	         }
	      }
	   } //End Of Thread2 Class
	   
	   
	   private static class Thread3 extends Thread {
		      public void run() {
		         synchronized (way1) {
		            System.out.println("Green: Way 1 is running....");
		            try {
		            	Thread.sleep(1000); 
		            	}
		            catch (InterruptedException e) {
		            	
		            	e.printStackTrace();
		            }
		            synchronized (way2) {
		            	
		               System.out.println("Red: Way 2 is stopped..");
		            }
		         }
		      }
		   }//End of Thread3 Class

}//End of Program Class
