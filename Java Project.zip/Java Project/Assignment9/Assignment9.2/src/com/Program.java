package com;


//Account Class
class Account{
	
	int balance;

	public Account() {
	
		//Giving balance value as 5000
		this.balance =5000;
	}
	
}


public class Program{
	
	//Creating account Object as a Static
	public static Account acc=new Account();
	
	
public static void main(String[] args) {
	
	Member1 mem1=new Member1();
	
	Member2 mem2=new Member2();
	mem1.start();
	
	mem2.start();
	
}
}
	
 class Member1 extends Thread{
	
	
	public void run(){
		
		//Locking Account Object
		synchronized(Program.acc){
			
			//Checking balance Amount before the Withdrawal of money
			if(Program.acc.balance==5000){
				
			Program.acc.balance=Program.acc.balance-3000;
			
			System.out.println("Member 1 had withdrawn 3000 from Account now account balnce is "+Program.acc.balance);
			}
			else {
				System.out.println("dear User !! You can't Withdraw money");
			
		}
		}
		}
	}


	

class Member2 extends Thread{
public void run(){
		
       //Locking Account Object	
		synchronized(Program.acc){
			
			//Checking balance Amount before the Withdrawal of money
			if(Program.acc.balance==5000){  
				
			Program.acc.balance=Program.acc.balance-3000;
			
			System.out.println("Member 2 had withdraw 3000 from Account now account balnce is "+Program.acc.balance);
			}
			else {
				
				System.out.println("dear User !! You can't Withdraw money");
			
		}
		}
		}
	}


